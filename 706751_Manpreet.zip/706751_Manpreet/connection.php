<?php

         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbname = "payroll";
         // Create connection
         $conn = mysqli_connect($servername, $username, $password,$dbname);


?>