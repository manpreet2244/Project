<html>

<head>
    <title>Payrol management system</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="stylesheet" href="assets/css/main.css" />

</head>

<body>

    <!-- Header -->
    <div id="header">

        <div class="top">

            <!-- Logo -->
            <div id="logo">
               
                <h1 id="title">Admin</h1>
                <p>Payroll Manager</p>
            </div>

            <!-- Nav -->
            <nav id="nav">

                <ul>
                    <li><a href="#top" id="top-link" class="skel-layers-ignoreHref"><span class="icon fa-home">Home</span></a></li>
                    <li><a href="#portfolio" id="portfolio-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Employee</span></a></li>
                    <li><a href="#about" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-th">list</span></a></li>
                    <li><a href="#contact" id="contact-link" class="skel-layers-ignoreHref"><span class="icon fa-envelope">Pay Slip</span></a></li>
                </ul>
            </nav>

        </div>

        <div class="bottom">

            <!-- Social Icons -->
            <ul class="icons">
                <li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
                <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
                <li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
                <li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
                <li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
            </ul>

        </div>

    </div>

    <!-- Main -->
    <div id="main">

        <!-- Intro -->
        <section id="top" class="one dark cover">
            <div class="container">

                <header>
                    <h2 class="alt">Payroll Management System</h2>
                    <p>Insert/Update/Delete</p>
                </header>

                <footer>
                    <a href="#portfolio" class="button scrolly">Employee</a>
                </footer>

            </div>
        </section>

        <!-- Portfolio -->
        <section id="portfolio" class="two">
            <div class="container">

                <header>
                    <h2>Employee</h2>
                </header>

                <p>Here you can add,delete or update any number of employees.</p>

                <div class="row">
                    <div class="4u 12u$(mobile)">
                        <article class="item">
                            <a href="insert.php" class="image fit"><img src="images/pic02.png" alt="" /></a>
                            <header>
                                <h3>Insert</h3>
                            </header>
                        </article>

                    </div>
                    <div class="4u 12u$(mobile)">
                        <article class="item">
                            <a href="delete1.php" class="image fit"><img src="images/pic03.png" alt="" /></a>
                            <header>
                                <h3>Delete</h3>
                            </header>
                        </article>

                    </div>
                    <div class="4u$ 12u$(mobile)">
                        <article class="item">
                            <a href="edit1.php" class="image fit"><img src="images/pic04.png" alt="" /></a>
                            <header>
                                <h3>Update</h3>
                            </header>
                        </article>

                    </div>
                </div>

            </div>
        </section>

        <!-- About Me -->
        <section id="about" class="three">
            <div class="container">

                <header>
                    
            </div>
        </section>

       
        <section id="contact" class="four">
            <div class="container">

                <header>
                    
                
            </div>
        </section>

    </div>

    <!-- Footer -->
    <div id="footer">

        <!-- Copyright -->
        <ul class="copyright">
        <li>&copy; PMS. All rights reserved.</li>
        <li>Design: Arsh</a></li>
        </ul>

    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.scrolly.min.js"></script>
    <script src="assets/js/jquery.scrollzer.min.js"></script>
    <script src="assets/js/skel.min.js"></script>
    <script src="assets/js/util.js"></script>
    <!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
    <script src="assets/js/main.js"></script>

</body>

</html>